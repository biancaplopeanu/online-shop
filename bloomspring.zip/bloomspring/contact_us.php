<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=">
  <title>Responsive Contact Us Page</title>
  <script src="https://kit.fontawesome.com/c32adfdcda.js" crossorigin="anonymous"></script>
  <link rel="stylesheet" href="contact_us_style.css">
</head>
<body>
  <section>
    <div class="section-header">
      <div class="container">
        <h2>Contacteaza-ne</h2>
        <p>Asteptam sa luati legatura cu noi in legatura cu orice inconvenient sau orice parere legata de produsele noastre , vom raspunde cat mai repede posibil la solicitarile tale! <br> Iti multumim ca ati ales serviciile noastre!</p>
      </div>
    </div>
    <div class="container">
      <div class="row">
        <div class="contact-info">
          <div class="contact-info-item">
            <div class="contact-info-icon">
              <i class="fas fa-home"></i>
            </div>
            <div class="contact-info-content">
              <h4>Adresa</h4>
              <p>Str. Izvoarelor,<br/> Nr. 13, <br/>Craiova,Dolj</p>
            </div>
          </div>
          <div class="contact-info-item">
            <div class="contact-info-icon">
              <i class="fas fa-phone"></i>
            </div>
            <div class="contact-info-content">
              <h4>Telefon</h4>
              <p>0253456987</p>
            </div>
          </div>
          <div class="contact-info-item">
            <div class="contact-info-icon">
              <i class="fas fa-envelope"></i>
            </div>
            <div class="contact-info-content">
              <h4>Email</h4>
             <p>bloom_spring@email.com</p>
            </div>
          </div>
        </div>
        <div class="contact-form">
          <form action="" id="contact-form">
            <h2>Mesaj</h2>
            <div class="input-box">
              <input type="text" required="true" name="">
              <span>Nume</span>
            </div>
            <div class="input-box">
              <input type="email" required="true" name="">
              <span>Email</span>
            </div>
            <div class="input-box">
              <textarea required="true" name=""></textarea>
              <span>Scrie mesajul tau aici...</span>
            </div>
            <div class="input-box">
              <input type="submit" value="Trimite"  onclick="window.location.href = 'index.php';"></input>
            </div>
          </form>
        </div>
      </div>
    </div>
  </section>
</body>
</html>
