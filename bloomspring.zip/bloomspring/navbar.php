<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <div class="container-fluid">
    <img src="./admin_area/logo.png" alt="" class="logo">
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" 
    aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="index.php">PRODUSE</a>
        </li>
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="about_us.php">DESPRE NOI</a>
        </li>
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="contact_us.php">CONTACT</a>
        </li>

       
        <?php
        if(isset($_SESSION['username'])){
          echo" <li class='nav-item'>
          <a class='nav-link' href='./users_area/profile.php'>CONTUL MEU</a>
        </li>";
        }else{
          echo" <li class='nav-item'>
          <a class='nav-link' href='./users_area/user_registration.php'>INREGISTARE</a>
        </li>";
        }
        ?>
        </form>
        <?php 
          if( (array_key_exists('username',$_SESSION)&& $_SESSION['username']!='admin') || !isset($_SESSION['username']) ){
          ?>
        <li class="nav-item">
          <a class="nav-link" href="cart.php"><i class="position-relative fa-sharp fa-solid fa-cart-shopping "><sup style="top:-0.6em"
           class="position-absolute start-100"><?php 
          cart_item();?></sup></i></a>
          </li>  
        <li class="nav-item">
          <a class="nav-link" href="#">TOTAL: <?php total_cart_price();?> LEI</a>
        </li>
        <?php } ?>
      </ul>
      <form class="d-flex" action="search_product.php" method="get">
        <input class="form-control me-2" type="search" placeholder="Cuvinte cheie" aria-label="Search" name="search_data">
        <input type="submit" value="Cauta" class="btn btn-outline-dark" name="search_data_product">
      </form>
    </div>
  </div>
</nav>