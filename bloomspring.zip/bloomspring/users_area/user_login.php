<?php include('../includes/connect.php'); 
    include('../functions/common_function.php');
    @session_start();
    ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Conectare</title>
  <!-- bootstrap link CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css">
  <link href="http://fots.googleapis.com/css?family=Cookie" rel="stylsheet" type="text/css">
    <link rel="stylesheet" href="../login.css">
    <style>
        body{
	font-family: sans-serif;	
	background-image: url(fundaal.jpg);
	background-repeat: no-repeat;
	overflow: hidden;
	background-size: cover;
        } 
    </style>
</head>
<body>
    <div class="container">
    <div class="header">
 		<h1>Conectare</h1>
 	</div>
     <div class="main">
            <form action="user_login.php" method="post">
                <span>
 				<i class="fa fa-user"></i>
 				<input type="text" id="user_username" placeholder="Introdu un username" autocomplete="off" name="user_username">
 			</span><br>
             <span>
 				<i class="fa fa-lock"></i>
 				<input type="password" id="user_password" placeholder="Introdu o parola" name="user_password" autocomplete="off">
 			</span><br>
                    <div class="text-center mt-4 pt-2">
                        <input type="submit" value="Conectare" class="btn btn-success py-2 px-3 border-0" name="user_login"></input>
                        <p class="mt-3 pt-2 fw-bold mb-0">Nu ai cont? <a href="user_registration.php"> Inregistreaza-te</a></p>
                    </div>
                </form>
            </div>
        </div>
</body>
</html>
<?php
if(isset($_POST['user_login'])){
    $user_username=$_POST['user_username'];
    $user_password=$_POST['user_password'];
    $select_query="Select * from `user_table` where username='$user_username'";
    $result=mysqli_query($con,$select_query);
    $row_count=mysqli_num_rows($result);
    $row_data=mysqli_fetch_assoc($result);
    $user_ip=getIPAddress();
    $select_query_cart="Select * from `cart_details` where ip_address='$user_ip'";
    $select_cart=mysqli_query($con,$select_query_cart);
    $row_count_cart=mysqli_num_rows($select_cart);
    if($row_count>0){
        $_SESSION['username']=$user_username;
        if(password_verify($user_password,$row_data['user_password'])){
                $_SESSION['username']=$user_username;
                echo"<script>window.open('profile.php','_self')</script>";
        }else{
            echo"<script>alert('Conectare invalida')</script>";
        }
    }else{
        echo"<script>alert('Conectare invalida')</script>";
    }
}
?>