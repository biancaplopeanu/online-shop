<!-- connect file -->
<?php
include('../includes/connect.php');
session_start();
if(isset($_GET['order_id'])){
    $order_id=$_GET['order_id'];
    // echo $order_id;
    $select_data="Select * from `user_orders` where order_id=$order_id";
    $result=mysqli_query($con,$select_data);
    $row_fetch=mysqli_fetch_assoc($result);
    $invoice_number=$row_fetch['invoice_number'];
    $amount_due=$row_fetch['amount_due'];
}
if(isset($_POST['confirm_payment'])){
    $invoice_number=$_POST['invoice_number'];
    $amount=$_POST['amount'];
    $payment_mode=$_POST['payment_mode'];
    $insert_query="insert into `user_payment` (order_id,invoice_number,amount,payment_mode)
    values ('$order_id','$invoice_number','$amount','$payment_mode')";
    $result=mysqli_query($con,$insert_query);
    if($result){
        echo "<h3 class='text-center text-light'>Plata efectuata cu succes</h3>";
        echo "<script>window.open('profile.php?my_orders','_self')</script>";
    }
    $update_orders="update `user_orders` set order_status='Complet' where order_id=$order_id";
    $result_orders=mysqli_query($con,$update_orders);
}
?>
<!DOCTYPE html>
<html lang="en">
<h3 class="text-center text-light"></h3>
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Confirma comanda</title>
  <!-- bootstrap link CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
</head>
<body class="bg-dark">
    <div class="container my-5 align-center text-light text-center">
        <h1 class="text-center text-light">Confirmare plata</h1>
        <form action="" method="post">
            <div class="form-outline my-5 text-center w-50 m-auto">
                <input type="text" class="form-control w-50 m-auto" name="invoice_number"
                value="<?php echo $invoice_number ?>">
            </div>
            <div class="form-outline my-4 text-center w-50 m-auto">
                <label for="" class="text-light mb-2">Suma</label>
                <input type="text" class="form-control w-50 m-auto mb-5" name="amount"
                value="<?php echo $amount_due?>">
            </div>
            <div class="form-check form-check-inline">
            <input class="form-check-input" type="radio" name="payment_mode" id="inlineRadio1" value="Ramburs">
            <label class="form-check-label" for="inlineRadio1">Ramburs</label>
            </div>
            <div class="form-check form-check-inline">
            <input class="form-check-input" type="radio" name="payment_mode" id="inlineRadio1" value="PayPal">
            <label class="form-check-label" for="inlineRadio1">PayPal</label>
            </div>
            <div class="form-check form-check-inline">
            <input class="form-check-input" type="radio" name="payment_mode" id="inlineRadio1" value="PayU">
            <label class="form-check-label" for="inlineRadio1">PayU</label>
            </div>
            <div class="form-check form-check-inline">
            <input class="form-check-input" type="radio" name="payment_mode" id="inlineRadio1" value="Revolut">
            <label class="form-check-label" for="inlineRadio1">Revolut</label>
            </div>
            <div class="form-check form-check-inline">
            <input class="form-check-input" type="radio" name="payment_mode" id="inlineRadio1" value="MasterCard">
            <label class="form-check-label" for="inlineRadio1">MasterCard</label>
            </div>
            <div class="form-outline my-5 text-center w-50 m-auto">
                <input type="submit"class="btn btn-success py-2 px-3 border-0" value="Confirm"
                name="confirm_payment">
            </div>
        </form>
    </div>
</body>
</html>