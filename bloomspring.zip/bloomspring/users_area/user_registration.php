<?php include('../includes/connect.php'); 
    include('../functions/common_function.php');
    ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Conectare</title>
  <!-- bootstrap link CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css">
  <link href="http://fots.googleapis.com/css?family=Cookie" rel="stylsheet" type="text/css">
    <link rel="stylesheet" href="../login.css">
    <style>
        body{
	font-family: sans-serif;	
	background-image: url(fundaal.jpg);
	background-repeat: round;
	overflow: scroll;
	background-size: cover;
        } 
    </style>
</head>
<body>
    <div class="container">
    <div class="header">
 		<h1>Inregistrare</h1>
 	</div>
     <div class="main">
            <form action="" method="post" enctype="multipart/form-data">
                <span>
 				<i class="fa fa-user"></i>
 				<input type="text" id="user_username" placeholder="Introdu un username" autocomplete="off" name="user_username">
 			</span><br>
             <span>
             <i class="fa fa-envelope"></i>
                 <input type="email" id="user_email"  placeholder="Introdu un email" autocomplete="off" name="user_email"/>
             </span><br>
             <span>
             <i class="fa fa-camera"></i>
                <input type="file" id="user_image" name="user_image"/>
                </span><br>
                <span>
 				<i class="fa fa-lock"></i>
 				<input type="password" id="user_password" placeholder="Introdu o parola" name="user_password" autocomplete="off">
 			</span><br>
             <span>
 				<i class="fa fa-lock"></i>
 				<input type="password" id="conf_user_password" placeholder="Confirma parola" name="conf_user_password" autocomplete="off">
 			</span><br>
             <span>
 				<i class="fa fa-map-marker"></i>
                        <input type="text" id="user_address" placeholder="Introdu o adresa" autocomplete="off" name="user_address"/>
                        </span><br>
                <span>
 				<i class="fa fa-mobile"></i>    
                        <input type="text" id="user_contact"  placeholder="Introdu un numar de telefon" autocomplete="off"  name="user_contact"/>
                 </span><br>
                    <div class="text-center mt-4 pt-2">
                        <input type="submit" value="Inregistrare" class="btn btn-success py-2 px-3 border-0" name="user_register"></input>
                        <p class="mt-3 pt-2 fw-bold mb-0">Ai deja cont? <a href="user_login.php"> Conecteaza-te</a></p>
                    </div>
                </form>
            </div>
        </div>
</body>
</html>
<!-- php code-->
<?php
if(isset($_POST['user_register'])){
    $user_username=$_POST['user_username'];
    $user_email=$_POST['user_email'];
    $user_password=$_POST['user_password'];
    $hash_password=password_hash($user_password,PASSWORD_DEFAULT);
    $conf_user_password=$_POST['conf_user_password'];
    $user_address=$_POST['user_address'];
    $user_contact=$_POST['user_contact'];
    $user_image=$_FILES['user_image']['name'];
    $user_image_tmp=$_FILES['user_image']['tmp_name'];
    $user_ip=getIPAddress();
    $select_query="Select * from `user_table` where username='$user_username' or user_email='$user_email'";
    $result=mysqli_query($con,$select_query);
    $rows_count=mysqli_num_rows($result);
    if($rows_count>0){
        echo "<script>alert('Username sau email existent deja')</script>";
    }else if($user_password!=$conf_user_password){
        echo"<script>alert('Parola nu se potriveste')</script>";
    }
    else{
    move_uploaded_file($user_image_tmp,"./user_images/$user_image");
    $insert_query="insert into `user_table` (username,user_email,
    user_password,user_image,user_ip,user_address,user_mobile) 
    values('$user_username','$user_email','$hash_password',
    '$user_image','$user_ip','$user_address','$user_contact')";
    $sql_execute=mysqli_query($con,$insert_query);
    echo"<script>window.open('user_login.php','_self')</script>";
    }
}
?>