<?php
include('../includes/connect.php');
if(isset($_POST['insert_product'])){
    $product_title=$_POST['product_title'];
    $description=$_POST['description'];
    $product_keywords=$_POST['product_keywords'];
    $product_category=$_POST['product_category'];
    $product_brands=$_POST['product_brands'];
    $product_price=$_POST['product_price'];
    $product_status='true';
    $product_image1=$_FILES['product_image1']['name'];
    $temp_image1=$_FILES['product_image1']['tmp_name'];
    if($product_title=='' or $description=='' or $product_keywords=='' or $product_category==''
     or $product_brands=='' or $product_price=='' or $product_image1=='' ){
        echo "<script>alert('Vă rugăm să completați toate câmpurile disponibile!')</script>";
        exit();
     } else{
        move_uploaded_file($temp_image1,"product_images/$product_image1");
        $insert_products="insert into `products` (product_title,product_description, 
        product_keywords,category_id,brand_id,product_image1,
        product_price,date,status) values ('$product_title','$description','$product_keywords',
        '$product_category','$product_brands','./product_images/$product_image1',
        '$product_price',NOW(),'$product_status')";
        $result_query=mysqli_query($con,$insert_products);
        if($result_query){
            echo "<script>alert('Produsul a fost introdus cu succes!')</script>";
            echo "<meta http-equiv='refresh' content='0'>";
            echo "<script>location.href='../admin_area';</script>";
        }
     }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Introdu produse</title>
  <!-- bootstrap link CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css">
  <link href="http://fots.googleapis.com/css?family=Cookie" rel="stylsheet" type="text/css">
    <link rel="stylesheet" href="../login.css">
    <style>
        body{
	font-family: sans-serif;	
	background-image: url(perfume.jpg);
	background-repeat: no-repeat;
	overflow: scroll;
	background-size: cover;
        } 
    </style>
</head>
<body>
    <div class="container">
    <div class="header">
 		<h1>Introdu Produse</h1>
 	</div>
     <div class="main">
            <form action="" method="post" enctype="multipart/form-data">
            <!-- title -->
            <span>
 				<i class="fa fa-star"></i>
 				<input type="text" id="product_title" placeholder="Introdu numele produsului" autocomplete="off" name="product_title">
 			</span><br>
            <!-- description -->
            <span>
 				<i class="fa fa-book"></i>
 				<input type="text" id="description" placeholder="Introdu descrierea produsului" autocomplete="off" name="description">
 			</span><br>
             <!--keywords -->
             <span>
 				<i class="fa fa-key"></i>
 				<input type="text" id="product_keywords" placeholder="Introdu cuvintele cheie pentru produs" autocomplete="off" name="product_keywords">
 			</span><br>
            <!--categories -->
            <div class="form-outline mb-4 w-50 m-auto">
                 <select name="product_category" id="" class="form-select">
                    <option value="">Selecteaza o categorie</option>
                    <?php
                        $select_query="Select * from `categories`";
                        $result_query=mysqli_query($con,$select_query);
                        while($row=mysqli_fetch_assoc($result_query)){
                            $category_title=$row['category_title'];
                            $category_id=$row['category_id'];
                            echo "<option value='$category_id'>$category_title</option>";
                        }
                    ?>
                 </select>             
            </div>
                   <!--brands-->
                   <div class="form-outline mb-4 w-50 m-auto">
                 <select name="product_brands" id="" class="form-select">
                    <option value="">Selecteaza un brand</option>
                    <?php
                        $select_query="Select * from `brands`";
                        $result_query=mysqli_query($con,$select_query);
                        while($row=mysqli_fetch_assoc($result_query)){
                            $brand_title=$row['brand_title'];
                            $brand_id=$row['brand_id'];
                            echo "<option value='$brand_id'>$brand_title</option>";
                        }
                    ?>
                 </select>             
            </div>
                 <!--image 1-->
                 <span>
             <i class="fa fa-camera"></i>
                <input type="file" id="product_image1" name="product_image1"/>
                </span><br>
                 <!--price -->
                 <span>
 				<i class="fa fa-money"></i>
 				<input type="text" id="product_price" placeholder="Introdu pretul produsului" autocomplete="off" name="product_price">
 			</span><br>
                <div class="form-outline mb-4 w-50 m-auto">
                    <input type="submit" class="btn btn-dark text-light border-0 p-2 my-3"  name="insert_product"  value="Introdu produs">  
                </div>              
            </div>
        </form>
    </div>
</body>
</html>