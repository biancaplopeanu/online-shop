<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="about_us_style.css">
    <title>Despre noi</title>
</head>
<body>
    <div class="wrapper">
        <div class="background-container">
            <div class="bg-1"></div>
            <div class="bg-2"></div>
        </div>
        <div class="about-container">
            <div class="image-container">
                <img src="download.gif" alt="">
            </div>
            <div class="text-container">
                <h1>Despre noi</h1>
                <p>Am creat acest brand pentru a va bucura de cele mai bune produse! <br><br> Vrei sa te rasfeti cu un parfum de lux sau sa daruiesti unei persoane dragi un strop de fericire?<br><br>Avem o gama variata din care puteti alege in functie de preferintele dumneavoastra!</p>
                <a href="index.php">Acasa</a>
            </div>
        </div>
    </div>
</body>
</html>