<h3 class="text-center">Toate platile</h3>
<table class="table table-bordered mt-5">
    <thead class="bg-dark">
        <?php
        $get_payment="Select * from `user_payment`";
        $result=mysqli_query($con,$get_payment);
        $row_count=mysqli_num_rows($result);
        echo " <tr class='text-light text-center'>
        <th>Nr</th>
        <th>Numar comanda</th>
        <th>Suma</th>
        <th>Mod de plata</th>
        <th>Data</th>
        </tr>
        </thead>
        <tbody>";
        if($row_count==0){
            echo "<h2 bg-danger text-center mt-5>Nu sunt plati momentan</h2>";
        }else{
            $number=0;
            while($row_data=mysqli_fetch_assoc($result)){
                $order_id=$row_data['order_id'];
                $payment_id=$row_data['payment_id'];
                $invoice_number=$row_data['invoice_number'];
                $amount=$row_data['amount'];
                $payment_mode=$row_data['payment_mode'];
                $date=$row_data['date'];
                $number++;
                echo " <tr class='text-center'>
                <td>$number</td>
                <td>$invoice_number</td>
                <td>$amount</td>
                <td>$payment_mode</td>
                <td>$date</td>
                </tr>";
            }
        }
        ?>
    </tbody>
</table>