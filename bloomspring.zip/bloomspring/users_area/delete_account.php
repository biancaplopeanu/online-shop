    <h3 class="text-danger mb-4">Sterge contul</h3>
    <form action="" method="post" class="mt-5">
        <div class="form-outline mb-4">
            <input type="submit" class="form-control btn-danger w-50 m-auto" name="delete" value="Sterge contul">
        </div>
        <div class="form-outline mb-4" >
            <input type="submit" class="form-control btn-success w-50 m-auto" name="dont_delete" value="Nu sterge contul">
        </div>
    </form>
    <?php
    $username_session=$_SESSION['username'];
    if(isset($_POST['delete'])){
    $delete_query="Delete from `user_table` where username='$username_session'";
    $result=mysqli_query($con, $delete_query);
    if($result){
        session_destroy();
        echo "<script>window.open('../index.php','_self')</script>";
    }
}
    if(isset($_POST['dont_delete'])){
        echo "<script>window.open('profile.php','_self')</script>";
}
?>
