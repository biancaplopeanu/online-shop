<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css">
  <link href="http://fots.googleapis.com/css?family=Cookie" rel="stylsheet" type="text/css">
  <link rel="stylesheet" href="./footer_style.css">
</head>
<body>
  <footer class="footer-distributed">
    <div class="footer-left">
      <p class="footer-links">
        <a href="index.php">Acasa</a>
        <a href="about_us.php">Despre noi</a>
        <a href="contact_us.php">Contact</a>
      </p>
      
    </div>
    <div class="footer-center">
      <div>
        <i class="fa fa-map-marker"></i>
        <p><span>Craiova</span></p>
      </div>
      <div>
      <i class="fa fa-phone"></i>
      <p>0253456789</p>
      </div>
      <div>
      <i class="fa fa-envelope"></i>
      <p>bloom_spring@gmail.com</p>
      </div>
    </div>
    <div class="footer-right">
      <p class="footer-company-about">
        <span>Despre Companie</span>
      </p>
      <div class="footer-icons">
        <a href="#"><i class="fa fa-facebook"></i></a>
        <a href="#"><i class="fa fa-instagram"></i></a>
        <a href="#"><i class="fa fa-twitter"></i></a>
        <a href="#"><i class="fa fa-youtube"></i></a>
        <a href="#"><i class="fa fa-linkedin"></i></a>
      </div>
    </div>
    <p class="footer-company-name">Copyright @ 2023 <strong> BloomSpring </strong> All rights reserved </p>
  </footer>
</body>
</html>