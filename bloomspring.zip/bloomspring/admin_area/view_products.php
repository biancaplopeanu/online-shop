    <h3 class="text-center">Toate produsele</h3>
    <table class="table table-bordered mt-5 align-center">
        <thead class="bg-dark text-light">
        <tr>
            <th>ID Produs</th>
            <th>Nume produs</th>
            <th>Imagine produs</th>
            <th>Pret produs</th>
            <th>Total vanzari</th>
            <th>Status</th>
            <th>Editeaza</th>
            <th>Sterge</th>
        </tr>
        </thead>
        <tbody>
            <?php
            $get_products="Select * from `products`";
            $result=mysqli_query($con,$get_products);
            $number=0;
            while($row=mysqli_fetch_assoc($result)){
                $product_id=$row['product_id'];
                $product_title=$row['product_title'];
                $product_image1=$row['product_image1'];
                $product_price=$row['product_price'];
                $status=$row['status'];
                $number++;
                ?>
                <tr class='text-center'>
               <td><?php echo $number ?></td>
               <td><?php echo $product_title ?></td>
               <td><img src='<?php echo $product_image1?>' class="product_img"/></td>
               <td><?php echo $product_price ?></td>
               <td><?php
               $get_count="Select * from `orders_pending` where product_id=$product_id";
               $resul_count=mysqli_query($con,$get_count);
               $rows_count=mysqli_num_rows($resul_count);
               echo $rows_count;
               ?>
               </td>
               <td><?php echo $status ?></td>
               <td><a href='index.php?edit_products=<?php echo $product_id?>' class='text-dark'><i class='fa-solid fa-pen-to-square'></i></a></td>
               <td><a href='index.php?delete_product=<?php echo $product_id?>' class='text-dark' type="button" class="btn btn-dark" data-toggle="modal" data-target="#exampleModal<?php echo $product_id?>"><i class='fa-solid fa-trash'></i></a></td>
           </tr>
           <div class="modal fade" id="exampleModal<?php echo $product_id?>"  tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-body">
        <h4>Esti sigur ca vrei sa stergi acest produs?</h4>    
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-success"><a href='./index.php?view_products' class="text_light text-decoration-none" style="color: white;">Nu</a></button>
        <button type="button" class="btn btn-danger"><a href='index.php?delete_product=<?php echo $product_id ?>'class="text-light text-decoration-none">Da</a></button>
      </div>
    </div>
  </div>
</div>
           <?php
            }
            ?>
        </tbody>
    </table>
    <!-- Modal -->
